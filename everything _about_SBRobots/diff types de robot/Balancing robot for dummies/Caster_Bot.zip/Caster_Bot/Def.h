//************************************************************************
//PIN OUTS
//************************************************************************

#define LEFT_MOTOR_PIN 2
#define RIGHT_MOTOR_PIN 3
#define TILT_PIN 5
#define PAN_PIN 6
#define SIREN 4
#define PW_PIN 7 //This is the signal input of the rangefinder
#define RANGEFINDER_SWITCH 8 //Plug the positive lead of the rangefinder here. This pin goes high when the rangefinder is activated, thus turning it on. (Power saving when off).
#define RANGEFINDER_LIGHT 13
#define LIGHT_PIN 23

//************************************************************************
//ASSIGN BUTTONS
//************************************************************************

#define GIMBAL_TOGGLE L1
#define SIREN_TOGGLE R1
#define DATA_TOGGLE START
#define RANGEFINDER_TOGGLE SQUARE
#define LIGHT_TOGGLE CROSS

//************************************************************************
//OFFSETS/LIMITS
//************************************************************************

#define CENTER 90
#define TILT_SHIFT -20
#define PAN_SHIFT 4
#define YAW_RANGE_MIN 20
#define YAW_RANGE_MAX 159
#define THROTTLE_MAX  113
#define THROTTLE_MIN 71

//************************************************************************
//SERVOS
//************************************************************************

Servo leftMotor;
Servo rightMotor;
Servo tilt;
Servo pan;

int leftStick = 0;
int rightStick = 0;

int leftOffset = -3;  //These store the trim values for the drive motors
int rightOffset = -1;

int tiltStick = 0;
int panStick  = 0;

//************************************************************************
//RANGEFINDER
//************************************************************************

#define RANGEFINDER_DELAY 100

boolean rangeToggle = false;

int pulse = 0;
int inches = 0;

//************************************************************************
//LOOP VARIABLES
//************************************************************************

boolean dataToggle = false;

long int currentTime = 0;
long int previousTime = 0;

//************************************************************************
//PS3 CONTROLLER
//************************************************************************

USB Usb;
BTD Btd(&Usb);
PS3BT PS3(&Btd); 

//************************************************************************
//MISCELLANEOUS SWITCHES
//************************************************************************

boolean lightOn = false;
